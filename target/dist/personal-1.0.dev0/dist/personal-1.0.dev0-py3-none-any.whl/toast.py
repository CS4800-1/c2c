#pip install win10toast
from win10toast import ToastNotifier

toaster = ToastNotifier()

toaster.show_toast("Title", "Message", duration=5)